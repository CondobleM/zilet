<?php

//SITE GLOBAL CONFIGURATION
$email = "ztrangeloops@gmail.com";   //<-- Your email

?>
